import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

import { HomePageRoutingModule } from './home-routing.module';
import { HomePage } from './home.page'; // standalone component

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    HomePageRoutingModule,
    HomePage   // <-- import standalone component here
  ],
  declarations: [] // <-- remove HomePage from declarations
})
export class HomePageModule {}