import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [
    CommonModule, // for *ngFor
    IonicModule  // for ion-header, ion-content, etc.
  ]
})
export class HomePage {

  tips = [
    {
      title: "Neck Stretch",
      content: "Gently tilt your head towards each shoulder and hold for 10 seconds on each side to relieve neck tension.",
      open: false
    },
    {
      title: "Shoulder Stretch",
      content: "Bring one arm across your chest and hold it for 15-20 seconds to loosen shoulders.",
      open: false
    },
    {
      title: "Back Stretch (Cat-Cow)",
      content: "On all fours, alternate arching and rounding your back slowly for 5-10 reps to increase spine flexibility.",
      open: false
    },
    {
      title: "Hamstring Stretch",
      content: "While seated, reach for your toes and hold for 15-20 seconds on each leg to stretch your hamstrings.",
      open: false
    },
    {
      title: "Calf Stretch",
      content: "Place your hands on a wall, step one leg back, and press the heel down for 15-20 seconds per leg to stretch calves.",
      open: false
    }
  ];

  toggleTip(index: number) {
    this.tips[index].open = !this.tips[index].open;
  }

}